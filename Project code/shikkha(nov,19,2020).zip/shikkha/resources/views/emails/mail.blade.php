Hello <strong>{{ $name }}</strong>,
<p>Hello world</p>
