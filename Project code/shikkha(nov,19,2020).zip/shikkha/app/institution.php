<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class institution extends Model
{
    protected $guarded=[];
}
