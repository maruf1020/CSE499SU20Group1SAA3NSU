

<?php $__env->startSection('section'); ?>


<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
  <!--begin::Subheader-->
  
  <!--end::Subheader-->
  <!--begin::Entry-->
  <div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
      <!--begin::Dashboard-->
      <h1 style="text-align: center;">This is an incomplete page. Please chose the page from sidebar and view the pages</h1><br><br><br>
      <h3 style="text-align: center;">About project:</h3><br>
      <h2 style="text-align: center;">North South University</h2><br>
      <h3 style="text-align: center;">Department of Eletrical & Computer Engineering</h3><br>
      <h2 style="text-align: center;">Project Name : Shikkhaa - A Study Management System</h2><br>
      <h2 style="text-align: center;">Faculty Name: Syed Athar Bin Amir (SAA3)</h2><br>
      <h3 style="text-align: center;">CSE499</h3>
      <h4 style="text-align: center;">Group: 01</h4>
      <h4 style="text-align: center;">Section: 16</h4>
      <h4 style="text-align: center;">Semester: Summer 2020</h4><br><br>
      <h4 style="">contributors</h4>
      <table class="table table-bordered table-dark">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">ID</th>
            <th scope="col">Email</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="row">1</th>
            <td>MD Maruf Billah</td>
            <td>1530671042</td>
            <td>maruf.billah@northsouth.edu</td>            
        </tr>
        <tr>
            <th scope="row">2</th>
            <td>Barkatullah Hossain</td>
            <td>1530642642</td>
            <td>barkat.ullah@northsouth.edu</td>            
        </tr>
        <tr>
            <th scope="row">3</th>
            <td>Ifthakharul Alam Shuvo</td>
            <td>1530421045</td>
            <td>alam.shuvo@northsouth.edu</td>            
        </tr>
        <tr>
            <th scope="row">3</th>
            <td>MD. Zakaria</td>
            <td>1430604042</td>
            <td>md.zakaria@northsouth.edu</td>            
        </tr>
      </tbody>
    </table><br><br>
      <h5 style="">ABSTRACT</h5>
      <h6 style="">On this modern era and pandemic situation there is necessity of online learning platform based on Bangladesh curriculum.
       Most of the educational institution doesn’t have any online learning management system.
        Some of them owned a system but which are not fully function and effective for both students and faculty members.
         On this pandemic situation numerous students regular educational work flow is getting hampered and lack of a systemic management system,
          institutions are unable to track/follow their protocol and facing difficulty manage their large number of students. Under this circumstance,
           there is a necessity to build such a kind of advance learning management system which will be universal for all institution,
            connect everything on one place and full fill their basic core.
      </h6><br><br>
      <div class="example-preview" style="text-align: center;">
          <p>
              <a href="https://app.slack.com/client/T017QGU1TD3/learning-slack" class="btn btn-primary">
                  <i class="fab fa-github"></i>
                  Github
              </a>
              <a href="https://trello.com/invite/b/AX0naDJb/c79014bfdbf759eaca7358010d24b405/cse499su20group1saa3nsu" class="btn btn-success">
                  <i class="fab fa-trello"></i>
                  Trello board
              </a> 
              <a href="https://github.com/maruf1020/CSE499SU20Group1SAA3NSU" class="btn btn-danger">
                  <i class="fab fa-slack"></i>
                  Slack
              </a> 
              <a href="https://www.facebook.com/tomardada/" class="btn btn-warning ">
                  <i class="fab fa-facebook"></i>
                  Facebook
              </a> 
              <a href="https://www.linkedin.com/in/maruf-billah-0699241aa/" class="btn btn-success">
                  <i class="fab fa-linkedin"></i>
                  Linkedin
              </a>   
          </p>          
      </div>      













      <!--begin::Row-->
      
      <!--end::Row-->
      <!--begin::Row-->
      
      <!--end::Row-->
      <!--end::Dashboard-->
    </div>
    <!--end::Container-->
  </div>
  <!--end::Entry-->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xaamp\Laravel\Sikk\CSE499SU20Group1SAA3NSU\Project code\shikkha\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>