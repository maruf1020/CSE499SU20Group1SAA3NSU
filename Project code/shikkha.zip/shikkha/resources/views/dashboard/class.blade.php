@extends('dashboard.layout.master')

@section('section')

<h1>my name is siam</h1>
<h1>my name is siam</h1>
<h1>my name is siam</h1>
<h1>my name is siam</h1>
<h1>my name is siam</h1>
@endsection
